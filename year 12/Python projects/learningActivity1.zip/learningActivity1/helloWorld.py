'''**********************************************************************************
* Hello world program
*
* Author: Joseph Healy
* Last Updated: 12/10/2023
*
*
**********************************************************************************'''

''' 
The quintessential first program!
using print() to output the string "Hello, world!" to the console!
No fancy variables, just a simple print statement!
'''
print("Hello, world!")
